# AccrediPro Standards Institute - Portal Structure

## Overview

This document outlines the complete portal architecture for AccrediPro Standards Institute, transforming from a course-selling platform to a professional certification authority with career services.

---

## Portal Domains & Branding

| Domain | Purpose | Audience |
|--------|---------|----------|
| **accredipro.institute** | Main certification portal | Students, professionals |
| **directory.accredipro.institute** | Public professional directory | Employers, clients, public |
| **learn.accredipro.institute** | Learning management system | Enrolled students |
| **verify.accredipro.institute** | Credential verification | Public verification |
| **corporate.accredipro.institute** | B2B services | Companies, clinics |

---

## Main Navigation Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ACCREDIPRO STANDARDS INSTITUTE                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  Certifications ▼  |  Directory  |  For Employers  |  About  |  Login  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Top Navigation (Public)

| Menu Item | Dropdown/Page |
|-----------|---------------|
| **Certifications** | → Functional Medicine, Holistic Nutrition, Health Coaching... (20 specialties) |
| **Directory** | → Find a Certified Professional |
| **For Employers** | → Hire Certified Professionals, Corporate Training |
| **About** | → Our Standards, Code of Ethics, Leadership |
| **Login** | → Student Portal Access |

---

## Page Structure: Public Website

### Homepage (accredipro.institute)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│         THE PROFESSIONAL CERTIFICATION STANDARD                         │
│         FOR HEALTH & WELLNESS PRACTITIONERS                             │
│                                                                         │
│    [Explore Certifications]        [Verify a Credential]                │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  WHY ACCREDIPRO CERTIFICATION?                                          │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                  │
│  │ Dedicated    │  │ 3 Credential │  │ Career       │                  │
│  │ Private Coach│  │ Levels       │  │ Services     │                  │
│  └──────────────┘  └──────────────┘  └──────────────┘                  │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CERTIFICATION PATHWAYS                                                 │
│                                                                         │
│  [Functional Medicine] [Holistic Nutrition] [Health Coaching]          │
│  [Gut Health] [Hormone Health] [Mental Wellness] ...                   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  THE 3-TIER CREDENTIAL SYSTEM                                           │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                  │
│  │   FC™        │  │   CP™        │  │   BC-™       │                  │
│  │  Foundation  │  │ Professional │  │    Board     │                  │
│  │    $297      │  │   $1,997     │  │   $5,997     │                  │
│  │  [Learn More]│  │  [Learn More]│  │    [Apply]   │                  │
│  └──────────────┘  └──────────────┘  └──────────────┘                  │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ⭐⭐⭐⭐⭐ 4.9 on Trustpilot | 1,000+ Reviews                          │
│                                                                         │
│  [Testimonial Carousel]                                                 │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  YOUR DEDICATED SUCCESS COACH                                           │
│                                                                         │
│  Every student receives a dedicated private coach who guides you        │
│  personally through certification — available 24/7.                     │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  UPCOMING COHORTS                                                       │
│                                                                         │
│  FM-FC™ Spring 2026 | Opens Jan 15 | 50 Spots | [Reserve Your Spot]    │
│  HN-FC™ Spring 2026 | Opens Jan 15 | 50 Spots | [Reserve Your Spot]    │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Specialty Landing Page (e.g., /functional-medicine)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│         FUNCTIONAL MEDICINE CERTIFICATION                               │
│         Become a Certified Functional Medicine Professional             │
│                                                                         │
│    [Start Your Journey - $297]        [Download Curriculum Guide]       │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CHOOSE YOUR CREDENTIAL LEVEL                                           │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ FM-FC™ | Functional Medicine Foundation Certified               │   │
│  │ 25 Hours | Entry Level | $297                                   │   │
│  │ Perfect for: Career explorers, wellness enthusiasts             │   │
│  │ Includes: Dedicated coach, cohort community, digital badge      │   │
│  │ Next Cohort: Spring 2026 (Opens Jan 15)                         │   │
│  │ [Enroll Now - $297]                                             │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ FM-CP™ | Certified Functional Medicine Professional             │   │
│  │ 75 Hours | Practitioner Level | $1,997                          │   │
│  │ Perfect for: Serious practitioners building a practice          │   │
│  │ Includes: Clinical mentor, monthly calls, career services       │   │
│  │ Prerequisite: FM-FC™ or equivalent                              │   │
│  │ [Apply Now - $1,997]                                            │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ BC-FMP™ | Board Certified Functional Medicine Practitioner      │   │
│  │ 150 Hours | Board Level | $5,997                                │   │
│  │ Perfect for: Elite practitioners, practice owners               │   │
│  │ Includes: Human mentor, weekly mastermind, board membership     │   │
│  │ Prerequisite: FM-CP™ required | Interview required              │   │
│  │ [Apply for Interview]                                           │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CURRICULUM OVERVIEW                                                    │
│  [Expandable modules with lesson previews]                              │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  YOUR DEDICATED COACH                                                   │
│  From day one, you'll have a private coach guiding your journey...     │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  WHAT'S INCLUDED                                                        │
│  [Value stack visualization by tier]                                    │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  SUCCESS STORIES                                                        │
│  [Graduate testimonials with photos]                                    │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FREQUENTLY ASKED QUESTIONS                                             │
│  - Is this certification recognized?                                    │
│  - How long does it take?                                               │
│  - What's the exam like?                                                │
│  - Can I get a refund?                                                  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Student Portal Structure

### Dashboard (/dashboard)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ACCREDIPRO STANDARDS INSTITUTE          🔔  💬 Coach  👤 Profile      │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Welcome back, [Name]!                                                  │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  💬 MESSAGE FROM YOUR COACH                                      │   │
│  │                                                                   │   │
│  │  "Great progress on Module 3! Ready to tackle the assessment?    │   │
│  │   I've prepared some review questions for you."                  │   │
│  │                                                                   │   │
│  │  [Continue Conversation]                                         │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  YOUR CERTIFICATIONS                                                    │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  FM-FC™ | Functional Medicine Foundation                        │   │
│  │  ████████████░░░░░░░░░░░░░░░░░░ 45% Complete                    │   │
│  │  Cohort: Spring 2026 | 12 of 50 classmates ahead                │   │
│  │  [Continue Learning]                                            │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  MY CIRCLE - Spring 2026 Cohort                                         │
│                                                                         │
│  🏆 Leaderboard                          📣 Recent Activity             │
│  1. Sarah M. - 78%                       - Lisa completed Module 2      │
│  2. Jennifer K. - 65%                    - Maria posted in discussion   │
│  3. Amanda R. - 52%                      - New study group forming      │
│  ...                                                                    │
│  24. You - 45%                                                          │
│                                                                         │
│  [View My Circle]                                                       │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  QUICK ACTIONS                                                          │
│                                                                         │
│  [📚 Resume Learning]  [💬 Ask Coach]  [👥 My Circle]  [📊 Progress]   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Sidebar Navigation (Student Portal)

```
┌────────────────────────┐
│  📊 Dashboard          │
│  📚 My Learning        │
│  💬 My Coach           │
│  👥 My Circle          │
│  🎓 Certifications     │
│  📋 Career Services    │
│  💳 Billing            │
│  ⚙️ Settings           │
└────────────────────────┘
```

---

## Student Portal Pages

### /my-learning

```
┌─────────────────────────────────────────────────────────────────────────┐
│  MY LEARNING                                                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ACTIVE CERTIFICATIONS                                                  │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  FM-FC™ Functional Medicine Foundation                          │   │
│  │                                                                   │   │
│  │  Module 1: Introduction ✅ Complete                              │   │
│  │  Module 2: Core Principles ✅ Complete                           │   │
│  │  Module 3: Assessment Methods 🔄 In Progress (Lesson 3 of 5)    │   │
│  │  Module 4: Client Protocols 🔒 Locked                            │   │
│  │  Module 5: Practice Integration 🔒 Locked                        │   │
│  │  Final Exam 🔒 Locked                                            │   │
│  │                                                                   │   │
│  │  [Continue: Module 3, Lesson 3]                                  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  AVAILABLE UPGRADES                                                     │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  FM-CP™ Certified Professional | Save $500 with upgrade         │   │
│  │  [Learn More]                                                    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### /my-coach

```
┌─────────────────────────────────────────────────────────────────────────┐
│  MY COACH                                                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  👩‍🏫 Your Dedicated Coach                                        │   │
│  │                                                                   │   │
│  │  "Hi [Name]! I'm here to support you through your                │   │
│  │   certification journey. Ask me anything!"                       │   │
│  │                                                                   │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │                                                                   │   │
│  │  [Chat history scrollable]                                       │   │
│  │                                                                   │   │
│  │  Coach: How are you feeling about Module 3?                      │   │
│  │                                                                   │   │
│  │  You: A bit confused about the assessment protocols...           │   │
│  │                                                                   │   │
│  │  Coach: That's completely normal! Let me break it down for you.  │   │
│  │  The key is to think of it in three steps...                    │   │
│  │                                                                   │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │                                                                   │   │
│  │  [Type your message...]                              [Send]      │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  QUICK TOPICS                                                           │
│  [Study Plan] [Exam Prep] [Module Help] [Motivation] [Schedule]        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### /my-circle

```
┌─────────────────────────────────────────────────────────────────────────┐
│  MY CIRCLE - FM-FC™ Spring 2026 Cohort                                  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [Feed]  [Members]  [Study Groups]  [Leaderboard]  [Resources]         │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  COHORT FEED                                                            │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  📢 COHORT ANNOUNCEMENT                                          │   │
│  │  "Week 3 Challenge: Complete Module 2 assessment by Friday       │   │
│  │   for a chance to win a free CP™ upgrade!"                       │   │
│  │   — AccrediPro Team                                              │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  👤 Sarah M.                                         2 hours ago │   │
│  │  "Just passed Module 3! The coach's review questions really      │   │
│  │   helped. Happy to share my notes if anyone needs them!"        │   │
│  │                                                                   │   │
│  │  ❤️ 12  💬 4 comments  [Reply]                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  👤 Jennifer K.                                      5 hours ago │   │
│  │  "Anyone want to form a study group for Module 4?                │   │
│  │   Thinking Tuesdays at 7pm EST on Zoom."                        │   │
│  │                                                                   │   │
│  │  ❤️ 8  💬 6 comments  [Reply]  [Join Study Group]               │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  [Write a post...]                                                      │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  COHORT STATS                                                           │
│  👥 50 Members | 📊 Avg Progress: 38% | 🎓 2 Certified This Week       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### /certifications

```
┌─────────────────────────────────────────────────────────────────────────┐
│  MY CERTIFICATIONS                                                      │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  EARNED CREDENTIALS                                                     │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  [Badge Image]    FM-FC™                                         │   │
│  │                   Functional Medicine Foundation Certified       │   │
│  │                   Issued: March 15, 2026                         │   │
│  │                   Expires: March 15, 2028                        │   │
│  │                   Credential ID: FM-FC-2026-00847                │   │
│  │                                                                   │   │
│  │  [Download Certificate]  [Share Badge]  [View Verification]     │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  IN PROGRESS                                                            │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  FM-CP™ | Certified Professional                                │   │
│  │  Progress: 45% | Est. Completion: June 2026                     │   │
│  │  [Continue Learning]                                            │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  NEXT LEVEL                                                             │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  BC-FMP™ | Board Certified                                       │   │
│  │  Prerequisite: Complete FM-CP™                                   │   │
│  │  [Learn About Board Certification]                               │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CONTINUING EDUCATION                                                   │
│  Credits Earned: 6/12 | Next Renewal: March 2028                       │
│  [Browse CE Opportunities]                                              │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### /career-services

```
┌─────────────────────────────────────────────────────────────────────────┐
│  CAREER SERVICES                                                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [My Profile]  [Directory]  [Job Board]  [Practice Services]           │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  YOUR DIRECTORY PROFILE                                                 │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Profile Status: LIVE ✅                                         │   │
│  │  Profile Type: Basic (FC™) | Upgrade to Featured (CP™)          │   │
│  │  Views This Month: 47                                            │   │
│  │  Contact Requests: 3                                             │   │
│  │                                                                   │   │
│  │  [Edit Profile]  [View Public Profile]  [Upgrade Listing]        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  JOB BOARD                                                              │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  🔥 NEW: Wellness Coach - Integrative Health Clinic, Austin TX  │   │
│  │  Requires: FM-FC™ or higher | $55-70k | Full-time               │   │
│  │  [View Details]  [Apply]                                        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Health Coach - Virtual Practice (Remote)                        │   │
│  │  Requires: FM-CP™ | Contract | Flexible hours                   │   │
│  │  [View Details]  [Apply]                                        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  [View All 24 Opportunities]                                            │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  PRACTICE LAUNCH SERVICES                                               │
│                                                                         │
│  Ready to start your own practice? We can help.                         │
│                                                                         │
│  [Website - $997]  [Branding - $497]  [Full Launch - $2,997]           │
│                                                                         │
│  💡 BC-™ Members receive 20% discount on all services                  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Professional Directory (Public)

### directory.accredipro.institute

```
┌─────────────────────────────────────────────────────────────────────────┐
│  FIND A CERTIFIED PROFESSIONAL                                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Search by:                                                             │
│  [Specialty ▼] [Location ▼] [Credential Level ▼] [🔍 Search]           │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FEATURED PROFESSIONALS (BC-™ Members)                                  │
│                                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │ [Photo]     │  │ [Photo]     │  │ [Photo]     │  │ [Photo]     │   │
│  │ Dr. Sarah M.│  │ Jennifer K. │  │ Amanda R.   │  │ Lisa T.     │   │
│  │ BC-FMP™     │  │ BC-FMP™     │  │ BC-HNC™     │  │ BC-HCP™     │   │
│  │ Austin, TX  │  │ Denver, CO  │  │ Miami, FL   │  │ Virtual     │   │
│  │ ⭐4.9 (47)  │  │ ⭐5.0 (23)  │  │ ⭐4.8 (31)  │  │ ⭐4.9 (89)  │   │
│  │ [View]      │  │ [View]      │  │ [View]      │  │ [View]      │   │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ALL RESULTS (847 Professionals)                                        │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ [Photo]  Maria G. | FM-CP™ Certified Professional               │   │
│  │          Functional Medicine | Chicago, IL                       │   │
│  │          "Helping women 40+ optimize their health naturally"    │   │
│  │          [View Profile] [Contact]                                │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  [Load More]                                                            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Individual Profile Page

```
┌─────────────────────────────────────────────────────────────────────────┐
│  SARAH MARTINEZ, BC-FMP™                                                │
│  Board Certified Functional Medicine Practitioner                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌────────────────┐                                                     │
│  │                │  Sarah Martinez, BC-FMP™                            │
│  │   [Photo]      │  Board Certified Functional Medicine Practitioner  │
│  │                │                                                     │
│  │                │  📍 Austin, TX (Also offers virtual sessions)       │
│  │                │  ⭐ 4.9 (47 reviews)                                │
│  └────────────────┘                                                     │
│                                                                         │
│  [BC-FMP™ Badge]  [FM-CP™ Badge]  [FM-FC™ Badge]                       │
│                                                                         │
│  ─────────────────────────────────────────────────────────────────────│
│                                                                         │
│  ABOUT                                                                  │
│  I help women 40+ uncover the root causes of fatigue, weight           │
│  resistance, and hormonal imbalances using functional medicine         │
│  principles. With over 150 supervised client cases...                  │
│                                                                         │
│  SPECIALTIES                                                            │
│  • Functional Medicine  • Hormone Health  • Gut Health                 │
│                                                                         │
│  CREDENTIALS                                                            │
│  • BC-FMP™ (Board Certified) - Issued 2025 ✅ Verified                 │
│  • FM-CP™ (Professional) - Issued 2024 ✅ Verified                     │
│  • FM-FC™ (Foundation) - Issued 2024 ✅ Verified                       │
│                                                                         │
│  [Contact Sarah]  [Visit Website]  [Verify Credentials]                │
│                                                                         │
│  ─────────────────────────────────────────────────────────────────────│
│                                                                         │
│  CLIENT REVIEWS                                                         │
│                                                                         │
│  ⭐⭐⭐⭐⭐ "Sarah changed my life. After years of fatigue..."         │
│  — Jennifer, Austin TX                                                  │
│                                                                         │
│  [See All 47 Reviews]                                                   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Credential Verification (Public)

### verify.accredipro.institute

```
┌─────────────────────────────────────────────────────────────────────────┐
│  VERIFY A CREDENTIAL                                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Enter the Credential ID to verify authenticity:                        │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Credential ID: [FM-FC-2026-00847          ]  [🔍 Verify]       │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  Or scan the QR code on any AccrediPro certificate.                    │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ✅ CREDENTIAL VERIFIED                                                 │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  Name: Sarah Martinez                                            │   │
│  │  Credential: FM-FC™ (Functional Medicine Foundation Certified)  │   │
│  │  Credential ID: FM-FC-2026-00847                                │   │
│  │  Issue Date: March 15, 2026                                      │   │
│  │  Expiration: March 15, 2028                                      │   │
│  │  Status: ACTIVE ✅                                               │   │
│  │                                                                   │   │
│  │  This credential is issued by AccrediPro Standards Institute    │   │
│  │  and meets all requirements for the FC™ designation.            │   │
│  │                                                                   │   │
│  │  [View Full Profile]                                             │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Corporate Portal (B2B)

### corporate.accredipro.institute

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ACCREDIPRO FOR ORGANIZATIONS                                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CERTIFY YOUR TEAM WITH THE INDUSTRY STANDARD                           │
│                                                                         │
│  [Request a Demo]  [Download Corporate Brochure]                        │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  SOLUTIONS                                                              │
│                                                                         │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐      │
│  │ TEAM             │  │ DEPARTMENT       │  │ ENTERPRISE       │      │
│  │ CERTIFICATION    │  │ TRAINING         │  │ PARTNERSHIP      │      │
│  │                  │  │                  │  │                  │      │
│  │ $197/person      │  │ $5,000           │  │ Custom           │      │
│  │ Min 5 people     │  │ Up to 25 people  │  │ Unlimited        │      │
│  │                  │  │                  │  │                  │      │
│  │ [Learn More]     │  │ [Learn More]     │  │ [Contact Us]     │      │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘      │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  WHY ORGANIZATIONS CHOOSE ACCREDIPRO                                    │
│                                                                         │
│  ✅ Industry-recognized credentials                                     │
│  ✅ Dedicated team dashboard                                            │
│  ✅ Progress tracking & reporting                                       │
│  ✅ Custom cohorts for your team                                        │
│  ✅ Dedicated support                                                   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  TRUSTED BY                                                             │
│  [Logo] [Logo] [Logo] [Logo] [Logo]                                    │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  BECOME AN APPROVED TRAINING PROVIDER                                   │
│                                                                         │
│  Offer AccrediPro certifications through your training business.       │
│                                                                         │
│  [Apply Now]                                                            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Application/Enrollment Funnel

### Step 1: Application Page (/apply/functional-medicine)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  APPLY FOR FUNCTIONAL MEDICINE CERTIFICATION                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Step 1 of 3: Tell Us About Yourself                                    │
│  ●───○───○                                                              │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  First Name: [________________]                                  │   │
│  │  Last Name:  [________________]                                  │   │
│  │  Email:      [________________]                                  │   │
│  │  Phone:      [________________]                                  │   │
│  │                                                                   │   │
│  │  Current Career Situation:                                       │   │
│  │  ○ New to wellness (career changer)                              │   │
│  │  ○ Currently in wellness/health field                            │   │
│  │  ○ Healthcare professional adding skills                         │   │
│  │  ○ Building my own practice                                      │   │
│  │                                                                   │   │
│  │  Why Functional Medicine?                                        │   │
│  │  [                                                   ]           │   │
│  │  [                                                   ]           │   │
│  │                                                                   │   │
│  │  When do you want to start?                                      │   │
│  │  ○ Immediately                                                   │   │
│  │  ○ Within 1 month                                                │   │
│  │  ○ Within 3 months                                               │   │
│  │  ○ Just exploring                                                │   │
│  │                                                                   │   │
│  │  ☑️ I am committed to completing this certification              │   │
│  │                                                                   │   │
│  │                              [Continue →]                        │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  🔒 Your information is secure and will never be shared                │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Step 2: Reserve Your Spot

```
┌─────────────────────────────────────────────────────────────────────────┐
│  RESERVE YOUR SPOT                                                      │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Step 2 of 3: Secure Your Enrollment                                    │
│  ●───●───○                                                              │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  FM-FC™ SPRING 2026 COHORT                                       │   │
│  │                                                                   │   │
│  │  ⚡ Only 12 spots remaining (of 50)                              │   │
│  │  📅 Cohort starts: February 1, 2026                              │   │
│  │  📅 Enrollment closes: January 31, 2026                          │   │
│  │                                                                   │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │                                                                   │   │
│  │  ENROLLMENT DEPOSIT: $17                                         │   │
│  │  (Applied to your $297 tuition)                                  │   │
│  │                                                                   │   │
│  │  This deposit:                                                   │   │
│  │  ✅ Reserves your spot in Spring 2026 cohort                    │   │
│  │  ✅ Activates your dedicated private coach immediately          │   │
│  │  ✅ Gives you access to pre-cohort orientation                  │   │
│  │  ✅ Is fully applied to your tuition                            │   │
│  │                                                                   │   │
│  │  [Card Number: ________________]                                 │   │
│  │  [MM/YY: ____] [CVC: ___]                                       │   │
│  │                                                                   │   │
│  │              [Reserve My Spot - $17 →]                           │   │
│  │                                                                   │   │
│  │  🔒 Secure payment via Stripe                                   │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Step 3: Welcome + Coach Assignment

```
┌─────────────────────────────────────────────────────────────────────────┐
│  WELCOME TO ACCREDIPRO!                                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Step 3 of 3: Meet Your Coach                                           │
│  ●───●───●                                                              │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                                                   │   │
│  │  🎉 Congratulations, [Name]!                                     │   │
│  │                                                                   │   │
│  │  Your spot in the FM-FC™ Spring 2026 Cohort is confirmed.       │   │
│  │                                                                   │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │                                                                   │   │
│  │  👩‍🏫 MEET YOUR DEDICATED COACH                                   │   │
│  │                                                                   │   │
│  │  Your private coach is ready to guide you through certification.│   │
│  │  She'll help you create a personalized study plan, answer your  │   │
│  │  questions 24/7, and ensure you're fully prepared for success.  │   │
│  │                                                                   │   │
│  │               [Start Your First Conversation →]                  │   │
│  │                                                                   │   │
│  │  ─────────────────────────────────────────────────────────────  │   │
│  │                                                                   │   │
│  │  NEXT STEPS:                                                     │   │
│  │  1. ✅ Spot reserved                                             │   │
│  │  2. 💬 Chat with your coach (start now!)                        │   │
│  │  3. 💳 Complete enrollment ($280 remaining before Feb 1)        │   │
│  │  4. 📚 Begin learning with your cohort                          │   │
│  │                                                                   │   │
│  │  [Complete Enrollment Now - $280]  [I'll Complete Later]        │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Admin Portal Structure

### /admin Dashboard

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ADMIN DASHBOARD                                                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  OVERVIEW                                                               │
│                                                                         │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐           │
│  │ $47,290   │  │ 156       │  │ 23        │  │ 89%       │           │
│  │ Revenue   │  │ Active    │  │ Certified │  │ Completion│           │
│  │ This Month│  │ Students  │  │ This Month│  │ Rate      │           │
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘           │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  COHORT STATUS                                                          │
│                                                                         │
│  FM-FC™ Spring 2026 | 47/50 enrolled | Starts Feb 1 | [Manage]         │
│  HN-FC™ Spring 2026 | 32/50 enrolled | Starts Feb 1 | [Manage]         │
│  FM-CP™ Q1 2026     | 18/30 enrolled | Starts Feb 20| [Manage]         │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  RECENT APPLICATIONS                                                    │
│                                                                         │
│  Sarah M. | FM-FC™ | Applied 2 hours ago | [Review]                    │
│  Jennifer K. | BC-FMP™ | Interview scheduled | [View]                  │
│  Amanda R. | FM-CP™ | Deposit paid | [View]                            │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Admin Sidebar

```
┌────────────────────────┐
│  📊 Dashboard          │
│  👥 Students           │
│  📚 Cohorts            │
│  🎓 Certifications     │
│  📋 Applications       │
│  💬 Coach Analytics    │
│  📈 Reports            │
│  💳 Billing            │
│  🏢 Corporate Clients  │
│  📣 Communications     │
│  ⚙️ Settings           │
└────────────────────────┘
```

---

## Technical Requirements

### Database Models (Additions to existing Prisma schema)

```prisma
model Cohort {
  id          String   @id @default(cuid())
  name        String   // "FM-FC™ Spring 2026"
  specialty   String   // "functional-medicine"
  tier        String   // "FC", "CP", "BC"
  maxSize     Int      @default(50)
  opensAt     DateTime
  closesAt    DateTime
  startsAt    DateTime
  status      String   // "upcoming", "enrolling", "active", "completed"
  enrollments Enrollment[]
  createdAt   DateTime @default(now())
}

model Application {
  id              String   @id @default(cuid())
  userId          String
  cohortId        String
  status          String   // "pending", "approved", "rejected", "enrolled"
  depositPaid     Boolean  @default(false)
  depositAmount   Float?
  answers         Json     // Application form answers
  interviewDate   DateTime?
  interviewNotes  String?
  createdAt       DateTime @default(now())

  user   User   @relation(fields: [userId], references: [id])
  cohort Cohort @relation(fields: [cohortId], references: [id])
}

model CoachConversation {
  id        String   @id @default(cuid())
  userId    String
  messages  Json     // Array of {role, content, timestamp}
  context   Json     // Student context for AI
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  user User @relation(fields: [userId], references: [id])
}

model DirectoryProfile {
  id           String   @id @default(cuid())
  userId       String   @unique
  headline     String?
  bio          String?
  specialties  String[] // Array of specialties
  location     String?
  website      String?
  isVirtual    Boolean  @default(false)
  isPublic     Boolean  @default(true)
  tier         String   // "basic", "featured", "premium"
  views        Int      @default(0)
  contacts     Int      @default(0)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  user User @relation(fields: [userId], references: [id])
}

model BoardMembership {
  id           String   @id @default(cuid())
  userId       String
  status       String   // "active", "lapsed", "suspended"
  joinedAt     DateTime @default(now())
  renewsAt     DateTime
  votingRights Boolean  @default(true)

  user User @relation(fields: [userId], references: [id])
}

model JobPosting {
  id           String   @id @default(cuid())
  employerId   String
  title        String
  description  String
  location     String
  salary       String?
  requirements String[] // Required credentials
  type         String   // "full-time", "part-time", "contract"
  isActive     Boolean  @default(true)
  createdAt    DateTime @default(now())
  expiresAt    DateTime

  applications JobApplication[]
}

model JobApplication {
  id          String   @id @default(cuid())
  jobId       String
  userId      String
  coverLetter String?
  status      String   // "pending", "reviewed", "interviewed", "hired", "rejected"
  createdAt   DateTime @default(now())

  job  JobPosting @relation(fields: [jobId], references: [id])
  user User       @relation(fields: [userId], references: [id])
}
```

---

## URL Structure Summary

### Public Pages
- `/` - Homepage
- `/certifications` - All certifications overview
- `/functional-medicine` - FM specialty page
- `/holistic-nutrition` - HN specialty page
- `/[specialty]` - Dynamic specialty pages
- `/about` - About AccrediPro
- `/standards` - Our Standards
- `/ethics` - Code of Ethics
- `/apply/[specialty]` - Application funnel
- `/verify` - Credential verification

### Student Portal (authenticated)
- `/dashboard` - Student dashboard
- `/my-learning` - Active courses/progress
- `/my-learning/[courseId]` - Course content
- `/my-coach` - Coach chat interface
- `/my-circle` - Cohort community
- `/certifications` - My credentials
- `/career-services` - Directory, jobs, services
- `/settings` - Account settings

### Directory (public)
- `/directory` - Search professionals
- `/directory/[userId]` - Individual profile

### Corporate (public + authenticated)
- `/corporate` - B2B landing page
- `/corporate/dashboard` - Corporate client dashboard

### Admin (authenticated)
- `/admin` - Admin dashboard
- `/admin/students` - Student management
- `/admin/cohorts` - Cohort management
- `/admin/applications` - Application review
- `/admin/certifications` - Credential management
- `/admin/coach` - Coach analytics
- `/admin/corporate` - B2B client management

---

*Document Version: 1.0*
*Created: January 2026*
*Last Updated: January 2026*
*Status: Technical Specification*
