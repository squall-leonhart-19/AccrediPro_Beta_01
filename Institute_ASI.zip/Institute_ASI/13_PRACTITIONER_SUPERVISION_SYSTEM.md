# Practitioner Supervision System — Complete Specification

> AccrediPro Standards Institute
> Coach Workspace + Practitioner Practice Management
> Version 1.0 | January 2026

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [The Three Portals](#the-three-portals)
3. [Practitioner Portal: "My Practice"](#practitioner-portal-my-practice)
4. [Mentor Portal: "Coach Workspace"](#mentor-portal-coach-workspace)
5. [Case Submission System](#case-submission-system)
6. [Supervision Hours Tracking](#supervision-hours-tracking)
7. [Mentor Management](#mentor-management)
8. [Client Referral Network](#client-referral-network)
9. [Database Schema](#database-schema)
10. [UI Specifications](#ui-specifications)
11. [Implementation Phases](#implementation-phases)

---

## Executive Summary

### The Reframe

At CP™ and BC-™ levels, members aren't just "students" — they're **practitioners with their own clients**. The system must support:

| Tier | Their Status | What They Need |
|------|-------------|----------------|
| FC™ | Learner | Study support (Sarah handles) |
| CP™ | New Practitioner | Case supervision, first client guidance |
| BC-™ | Established Practitioner | Advanced case review, business mentoring |
| MC-™ | Industry Leader | Peer collaboration, content creation |

### Key Insight

> **"Students" become "Practitioners" who have "Clients"**
>
> Our mentors don't manage students — they **supervise practitioners** who are working with real clients in the field.

### System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        PRACTITIONER                              │
│              (CP™ or BC-™ Certified Member)                     │
│                                                                  │
│  • Works with their own clients                                 │
│  • Submits cases for supervision                                │
│  • Logs hours toward certification                              │
│  • Receives feedback and guidance                               │
└─────────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────────┐
│                      ASI MENTOR                                  │
│            (Staff, Contracted, or MC-™ Graduate)                │
│                                                                  │
│  • Reviews submitted cases                                       │
│  • Provides clinical feedback                                   │
│  • Approves supervision hours                                   │
│  • Conducts live supervision sessions                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## The Three Portals

### Portal Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│   STUDENT PORTAL                    PRACTITIONER PORTAL          │
│   (FC™ and learning)                (CP™+ with clients)         │
│                                                                  │
│   • My Learning                     • My Clients                 │
│   • Coach Sarah                     • Case Submissions           │
│   • My Credentials                  • Supervision Sessions       │
│   • Community                       • Practice Tools             │
│   • Practice & Earn                 • Client Referrals           │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   MENTOR PORTAL (Coach Workspace)                               │
│   (INSTRUCTOR, MENTOR, SENIOR_COACH roles)                      │
│                                                                  │
│   • My Practitioners                                            │
│   • Case Reviews                                                │
│   • Supervision Sessions                                        │
│   • Hours Certification                                         │
│   • Mentor Resources                                            │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ADMIN PORTAL                                                  │
│   (Staff only)                                                  │
│                                                                  │
│   • All practitioners overview                                  │
│   • Mentor management                                           │
│   • Supervision metrics                                         │
│   • Quality assurance                                           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Access by Role

| Role | Student Portal | Practitioner Portal | Coach Workspace | Admin |
|------|---------------|--------------------|-----------------| ------|
| STUDENT | ✅ | ❌ | ❌ | ❌ |
| STUDENT + CP™ | ✅ | ✅ | ❌ | ❌ |
| STUDENT + BC-™ | ✅ | ✅ | ❌ | ❌ |
| MENTOR | ✅ | ✅ (if certified) | ✅ | ❌ |
| INSTRUCTOR | ✅ | ✅ (if certified) | ✅ | ❌ |
| ADMIN | ✅ | ✅ | ✅ | ✅ |

---

## Practitioner Portal: "My Practice"

### Navigation Structure

For CP™ and BC-™ members, add a new **"My Practice"** section in the sidebar:

```
📋 MY PRACTICE
├── Dashboard
│   ├── Active clients count
│   ├── Cases pending review
│   ├── Hours toward certification
│   └── Next supervision session
│
├── My Clients
│   ├── Add New Client
│   ├── Active Clients
│   ├── Archived Clients
│   └── Client Notes & Progress
│
├── Case Submissions
│   ├── Submit New Case
│   ├── Pending Review (awaiting mentor)
│   ├── In Review (mentor working on it)
│   ├── Reviewed (with feedback)
│   └── All Submissions
│
├── Supervision
│   ├── My Supervisor (assigned mentor)
│   ├── Scheduled Sessions
│   ├── Session History
│   └── Hours Log
│
├── Practice Tools
│   ├── Intake Forms (by specialty)
│   ├── Protocol Templates
│   ├── Session Note Templates
│   ├── Client Handouts
│   └── Assessment Tools
│
└── Referrals (BC-™ Only)
    ├── Available Leads
    ├── My Claimed Leads
    ├── Lead Settings
    └── Referral History
```

### My Practice Dashboard

```
┌─────────────────────────────────────────────────────────────────┐
│                     MY PRACTICE DASHBOARD                        │
│                                                                  │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │   ACTIVE    │ │   CASES     │ │   HOURS     │ │    NEXT     ││
│  │  CLIENTS    │ │  PENDING    │ │  LOGGED     │ │  SESSION    ││
│  │             │ │             │ │             │ │             ││
│  │     12      │ │      3      │ │   42/90     │ │  Jan 15     ││
│  │             │ │             │ │    47%      │ │   2:00pm    ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📊 SUPERVISION PROGRESS (BC-FMP™ Track)                        │
│                                                                  │
│  ████████████████████░░░░░░░░░░  42 / 90 hours (47%)           │
│                                                                  │
│  Client Sessions:     ████████████░░░░░░░░  28 / 50             │
│  Case Supervision:    ██████░░░░░░░░░░░░░░   8 / 20             │
│  Group Supervision:   ████░░░░░░░░░░░░░░░░   4 / 10             │
│  Peer Consultation:   ████░░░░░░░░░░░░░░░░   2 / 10             │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  🩺 MY SUPERVISOR                                               │
│                                                                  │
│  ┌────────┐  Dr. Sarah Martinez, BC-FMP™                       │
│  │  [📷]  │  Senior Clinical Mentor                            │
│  │        │  Specialty: Functional Medicine                    │
│  └────────┘  Response time: Usually within 24 hours            │
│                                                                  │
│              [MESSAGE] [SCHEDULE SESSION]                        │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📝 RECENT CASE FEEDBACK                                        │
│                                                                  │
│  • "Maria G." case — ★★★★☆ Reviewed Jan 8                      │
│    "Excellent gut-brain connection. Consider cortisol..."       │
│    [VIEW FULL FEEDBACK]                                         │
│                                                                  │
│  • "Jennifer L." case — ★★★★★ Reviewed Jan 5                   │
│    "Outstanding protocol. Ready for complex cases."             │
│    [VIEW FULL FEEDBACK]                                         │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ⚡ QUICK ACTIONS                                               │
│                                                                  │
│  [+ ADD CLIENT] [SUBMIT CASE] [SCHEDULE SUPERVISION]            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### My Clients (Simple CRM)

```
┌─────────────────────────────────────────────────────────────────┐
│  MY CLIENTS                                    [+ ADD CLIENT]    │
│                                                                  │
│  🔍 Search clients...                    Filter: [All ▼]        │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  Maria G.              Active        Last: Jan 8, 2026     │ │
│  │  Chief Concern: Fatigue, digestive issues                  │ │
│  │  Sessions: 4  |  Cases Submitted: 2                        │ │
│  │                      [VIEW] [ADD NOTE] [SUBMIT CASE]       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  Jennifer L.           Active        Last: Jan 5, 2026     │ │
│  │  Chief Concern: Hormonal imbalance, weight                 │ │
│  │  Sessions: 6  |  Cases Submitted: 3                        │ │
│  │                      [VIEW] [ADD NOTE] [SUBMIT CASE]       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  Robert M.             Active        Last: Jan 3, 2026     │ │
│  │  Chief Concern: Blood sugar regulation                     │ │
│  │  Sessions: 2  |  Cases Submitted: 1                        │ │
│  │                      [VIEW] [ADD NOTE] [SUBMIT CASE]       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Showing 3 of 12 clients                    [Load More]         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Add New Client Form

```
┌─────────────────────────────────────────────────────────────────┐
│                        ADD NEW CLIENT                            │
│                                                                  │
│  ⚠️  Privacy Notice: Use pseudonyms only. Never enter real      │
│      names or identifying information. This protects both       │
│      you and your client.                                        │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  Client Pseudonym *                                              │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ e.g., "Maria G." or "Client #47"                        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Demographics (optional, for case context)                       │
│  Age Range: [40-50 ▼]    Gender: [Female ▼]                     │
│                                                                  │
│  Chief Concerns *                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Primary health concerns or goals...                      │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Specialty Area *                                                │
│  ○ Functional Medicine                                           │
│  ○ Women's Health                                                │
│  ○ Nutrition Coaching                                            │
│  ○ Autism & ADHD                                                 │
│  ○ Other: ___________                                            │
│                                                                  │
│  Start Date                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 📅 January 8, 2026                                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Notes (private, not shared with supervisor)                     │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│                    [CANCEL]  [ADD CLIENT]                        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Mentor Portal: "Coach Workspace"

### Who Are Mentors?

| Type | Description | Access |
|------|-------------|--------|
| **Staff Mentor** | Full-time ASI employee | Full workspace |
| **Contract Mentor** | Part-time, per-hour | Assigned practitioners only |
| **MC-™ Mentor** | Master-level graduates | Specialty-specific |
| **Guest Expert** | Industry leaders | Session-specific |

### Navigation Structure

```
🩺 COACH WORKSPACE
├── Dashboard
│   ├── Practitioners assigned
│   ├── Cases pending review
│   ├── Sessions this week
│   └── Hours certified this month
│
├── My Practitioners
│   ├── Active (assigned to me)
│   ├── By Specialty
│   ├── By Tier (CP™ vs BC-™)
│   └── Progress Overview
│
├── Case Reviews
│   ├── Pending (new submissions)
│   ├── In Review (I'm working on)
│   ├── Completed (reviewed)
│   └── All Cases
│
├── Supervision Sessions
│   ├── Calendar
│   ├── Scheduled Sessions
│   ├── Session Notes
│   └── Recordings
│
├── Hours Certification
│   ├── Pending Approval
│   ├── Approved This Month
│   └── By Practitioner
│
├── Group Supervision
│   ├── Upcoming Calls
│   ├── Past Recordings
│   └── Attendance
│
└── Resources
    ├── Mentor Playbook
    ├── Review Templates
    ├── Feedback Guidelines
    └── Specialty Resources
```

### Coach Workspace Dashboard

```
┌─────────────────────────────────────────────────────────────────┐
│                    COACH WORKSPACE DASHBOARD                     │
│                                                                  │
│  Welcome back, Dr. Sarah Martinez                               │
│                                                                  │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │PRACTITIONERS│ │   CASES     │ │  SESSIONS   │ │   HOURS     ││
│  │  ASSIGNED   │ │  PENDING    │ │ THIS WEEK   │ │ CERTIFIED   ││
│  │             │ │             │ │             │ │ THIS MONTH  ││
│  │     18      │ │      5      │ │      4      │ │     62      ││
│  │             │ │  ⚠️ 2 urgent│ │             │ │             ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ⚠️ REQUIRES ATTENTION                                          │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ 🔴 Case from Jennifer Smith — Submitted 3 days ago         │ │
│  │    "Complex autoimmune presentation with gut involvement"  │ │
│  │    [REVIEW NOW]                                            │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ 🟡 Case from Michael Chen — Submitted 2 days ago           │ │
│  │    "First client intake - thyroid concerns"                │ │
│  │    [REVIEW NOW]                                            │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📅 TODAY'S SCHEDULE                                            │
│                                                                  │
│  • 10:00 AM — 1:1 Supervision: Amanda Brooks (BC-™)            │
│  • 2:00 PM — Group Supervision Call (8 practitioners)          │
│  • 4:30 PM — Case Review Block (3 pending)                     │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📊 MY PRACTITIONERS - PROGRESS OVERVIEW                        │
│                                                                  │
│  BC-™ Track (12 practitioners):                                 │
│  ████████████████████░░░░░░░░░░  Average: 58% complete         │
│                                                                  │
│  CP™ Track (6 practitioners):                                   │
│  ████████░░░░░░░░░░░░░░░░░░░░░░  Average: 34% complete         │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ⚡ QUICK ACTIONS                                               │
│                                                                  │
│  [REVIEW CASES] [SCHEDULE SESSION] [VIEW ALL PRACTITIONERS]    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### My Practitioners List

```
┌─────────────────────────────────────────────────────────────────┐
│  MY PRACTITIONERS                                                │
│                                                                  │
│  🔍 Search...     Tier: [All ▼]  Specialty: [All ▼]  Sort: [▼] │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ ┌────┐  Jennifer Smith                      BC-FMP™ Track  │ │
│  │ │ 📷 │  Functional Medicine                                │ │
│  │ └────┘  Progress: ████████████░░░░  72%    Clients: 8     │ │
│  │         Last case: Jan 8 (pending review)                  │ │
│  │         Hours: 65/90                                        │ │
│  │                    [VIEW] [MESSAGE] [REVIEW CASE]          │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ ┌────┐  Michael Chen                        FM-CP™ Track   │ │
│  │ │ 📷 │  Functional Medicine                                │ │
│  │ └────┘  Progress: ████░░░░░░░░░░░░  28%    Clients: 3     │ │
│  │         Last case: Jan 6 (pending review)                  │ │
│  │         Hours: 14/50                                        │ │
│  │                    [VIEW] [MESSAGE] [REVIEW CASE]          │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ ┌────┐  Amanda Brooks                       BC-FMP™ Track  │ │
│  │ │ 📷 │  Functional Medicine                                │ │
│  │ └────┘  Progress: ██████████████░░  85%    Clients: 12    │ │
│  │         Last case: Jan 7 (reviewed ✓)                      │ │
│  │         Hours: 77/90 — Almost complete!                    │ │
│  │                    [VIEW] [MESSAGE] [SCHEDULE FINAL]       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Showing 3 of 18 practitioners                [View All]        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Case Submission System

### Practitioner Submits Case

```
┌─────────────────────────────────────────────────────────────────┐
│                     SUBMIT CASE FOR REVIEW                       │
│                                                                  │
│  ⚠️  All client information must be de-identified.              │
│      Use pseudonyms only. Never include real names,             │
│      addresses, or other identifying details.                   │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  SELECT CLIENT *                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Maria G.                                             ▼   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  SESSION DETAILS                                                 │
│                                                                  │
│  Session Date *         Session Type *                           │
│  ┌───────────────┐     ○ Initial Intake                         │
│  │ Jan 8, 2026   │     ● Follow-up Session                      │
│  └───────────────┘     ○ Protocol Review                        │
│                        ○ Progress Check                          │
│                                                                  │
│  Duration *                                                      │
│  ┌───────────────┐                                              │
│  │ 60 minutes    │                                              │
│  └───────────────┘                                              │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  CLINICAL INFORMATION                                            │
│                                                                  │
│  Chief Concerns / Session Focus *                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Client presented with ongoing fatigue despite previous   │   │
│  │ gut protocol. Reports 60% improvement in digestion but   │   │
│  │ energy still low, especially afternoon crashes...        │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Relevant History / Updates *                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ - 4 weeks on elimination diet                            │   │
│  │ - GI-MAP showed improved dysbiosis markers               │   │
│  │ - Sleep still disrupted (waking 3-4am)                   │   │
│  │ - Stress levels high (job transition)                    │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Your Assessment *                                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Suspect HPA axis dysfunction given:                      │   │
│  │ - Early morning waking pattern                           │   │
│  │ - Afternoon energy crashes                               │   │
│  │ - High stress context                                    │   │
│  │ - Gut improvement not translating to energy              │   │
│  │                                                          │   │
│  │ Also considering thyroid contribution given fatigue      │   │
│  │ pattern and client's age (perimenopause possible).       │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Your Recommendations *                                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 1. DUTCH Complete test to assess cortisol pattern        │   │
│  │ 2. Full thyroid panel (TSH, Free T3/T4, antibodies)     │   │
│  │ 3. Continue current gut protocol                         │   │
│  │ 4. Add adaptogen support (ashwagandha)                   │   │
│  │ 5. Sleep hygiene protocol + magnesium glycinate          │   │
│  │ 6. Stress management: 10-min morning breathwork          │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Questions for Supervisor                                        │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 1. Should I prioritize DUTCH or thyroid testing first?   │   │
│  │ 2. Any concern about adding ashwagandha with her         │   │
│  │    current supplements?                                   │   │
│  │ 3. Would you recommend any specific breathwork protocol? │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ATTACHMENTS (optional)                                          │
│                                                                  │
│  [+ Add intake form]  [+ Add lab results]  [+ Add protocol]     │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  HOURS TO LOG                                                    │
│                                                                  │
│  Session time (60 min) + Documentation (30 min estimated)       │
│                                                                  │
│  Hours to credit: ┌──────┐                                      │
│                   │ 1.5  │                                      │
│                   └──────┘                                      │
│                                                                  │
│                       [SAVE DRAFT]  [SUBMIT FOR REVIEW]         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Mentor Reviews Case

```
┌─────────────────────────────────────────────────────────────────┐
│  CASE REVIEW                                                     │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Submitted by: Jennifer Smith (BC-FMP™ Track)               │ │
│  │ Client: Maria G.  |  Session: Follow-up  |  Jan 8, 2026   │ │
│  │ Specialty: Functional Medicine                             │ │
│  │ Hours Requested: 1.5                                       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📋 SUBMISSION DETAILS                      [Expand All]        │
│                                                                  │
│  ▼ Chief Concerns                                               │
│    Client presented with ongoing fatigue despite previous       │
│    gut protocol. Reports 60% improvement in digestion but       │
│    energy still low, especially afternoon crashes...            │
│                                                                  │
│  ▼ Relevant History                                             │
│    - 4 weeks on elimination diet                                │
│    - GI-MAP showed improved dysbiosis markers                   │
│    - Sleep still disrupted (waking 3-4am)...                    │
│                                                                  │
│  ▼ Practitioner's Assessment                                    │
│    Suspect HPA axis dysfunction given early morning waking      │
│    pattern, afternoon crashes, high stress context...           │
│                                                                  │
│  ▼ Practitioner's Recommendations                               │
│    1. DUTCH Complete test                                       │
│    2. Full thyroid panel                                        │
│    3. Continue gut protocol...                                  │
│                                                                  │
│  ▼ Questions for You                                            │
│    1. Should I prioritize DUTCH or thyroid testing first?       │
│    2. Any concern about adding ashwagandha?                     │
│    3. Would you recommend specific breathwork protocol?         │
│                                                                  │
│  📎 Attachments: intake_form.pdf, gimap_results.pdf             │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ✍️ YOUR REVIEW                                                 │
│                                                                  │
│  COMPETENCY RATINGS                                              │
│                                                                  │
│  Clinical Reasoning      ○ ○ ○ ○ ●  (4/5)                       │
│  Assessment Skills       ○ ○ ○ ● ○  (4/5)                       │
│  Protocol Design         ○ ○ ○ ○ ●  (5/5)                       │
│  Documentation Quality   ○ ○ ● ○ ○  (3/5)                       │
│  Client Communication    ○ ○ ○ ● ○  (4/5)                       │
│                                                                  │
│  Overall: ★★★★☆ (4.0 / 5.0)                                     │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  DETAILED FEEDBACK *                                             │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Excellent clinical thinking, Jennifer! Your HPA axis     │   │
│  │ hypothesis is well-supported by the symptom pattern.     │   │
│  │                                                          │   │
│  │ Regarding your questions:                                │   │
│  │                                                          │   │
│  │ 1. DUTCH vs Thyroid: I'd prioritize DUTCH first given   │   │
│  │    the classic 3-4am waking pattern. This strongly       │   │
│  │    suggests cortisol dysregulation. Thyroid can wait     │   │
│  │    2-3 weeks unless symptoms worsen.                     │   │
│  │                                                          │   │
│  │ 2. Ashwagandha: Safe to add. Consider starting at        │   │
│  │    300mg and titrating up. Watch for any digestive       │   │
│  │    sensitivity given her gut history.                    │   │
│  │                                                          │   │
│  │ 3. Breathwork: Box breathing (4-4-4-4) is my go-to for  │   │
│  │    HPA axis cases. 5 minutes morning, 5 before bed.      │   │
│  │                                                          │   │
│  │ One improvement: Your documentation could include more   │   │
│  │ specific timeline markers. When exactly did fatigue      │   │
│  │ start? Correlation with life events?                     │   │
│  │                                                          │   │
│  │ Keep up the great work! You're ready for more complex    │   │
│  │ multi-system cases.                                       │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ACTION ITEMS FOR PRACTITIONER                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑ Prioritize DUTCH Complete testing                      │   │
│  │ ☑ Start ashwagandha at 300mg, titrate up                │   │
│  │ ☑ Implement box breathing protocol                       │   │
│  │ ☑ Improve timeline documentation in future cases         │   │
│  │ ☐ Add item...                                            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  HOURS CERTIFICATION                                             │
│                                                                  │
│  Requested: 1.5 hours                                            │
│  Approved:  ┌──────┐  (adjust if needed)                        │
│             │ 1.5  │                                            │
│             └──────┘                                            │
│                                                                  │
│  Hour Type: [Case Supervision ▼]                                │
│                                                                  │
│                                                                  │
│           [SAVE DRAFT]  [REQUEST REVISION]  [APPROVE & SEND]    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Supervision Hours Tracking

### Hours Required by Tier

#### CP™ → BC-™ Advancement (Required for BC-™ Eligibility)

| Category | Hours Required | Description |
|----------|---------------|-------------|
| Client Sessions | 50 | Documented work with real clients |
| Case Supervision | 20 | Cases reviewed by ASI mentor |
| Group Supervision | 10 | Monthly group supervision calls |
| Peer Consultation | 10 | Documented peer case discussions |
| **Total** | **90** | Before BC-™ exam eligibility |

#### BC-™ → MC-™ Advancement

| Category | Hours Required | Description |
|----------|---------------|-------------|
| Advanced Client Work | 100 | Complex/multi-system cases |
| Advanced Supervision | 30 | Mentor case consultation |
| Teaching/Mentoring | 30 | Supervising CP™ practitioners |
| Research/Publication | 20 | Contributing to the field |
| Capstone Project | 20 | Original contribution |
| **Total** | **200** | Before MC-™ eligibility |

### Hours Dashboard (Practitioner View)

```
┌─────────────────────────────────────────────────────────────────┐
│              MY SUPERVISION HOURS — BC-FMP™ Track               │
│                                                                  │
│  Overall Progress                                                │
│  ████████████████████░░░░░░░░░░  62 / 90 hours (69%)           │
│                                                                  │
│  Estimated completion: March 2026 (at current pace)             │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  BREAKDOWN BY CATEGORY                                           │
│                                                                  │
│  Client Sessions (50 required)                                   │
│  ████████████████░░░░░░░░░░░░░░  32 / 50  (64%)                │
│  ✓ Last logged: Jan 8, 2026 (Maria G. session)                  │
│                                                                  │
│  Case Supervision (20 required)                                  │
│  ████████████████████░░░░░░░░░░  18 / 20  (90%)                │
│  ✓ Last approved: Jan 8, 2026 (Dr. Martinez)                    │
│                                                                  │
│  Group Supervision (10 required)                                 │
│  ████████░░░░░░░░░░░░░░░░░░░░░░   8 / 10  (80%)                │
│  ✓ Next call: Jan 15, 2026 @ 2:00 PM                            │
│                                                                  │
│  Peer Consultation (10 required)                                 │
│  ████░░░░░░░░░░░░░░░░░░░░░░░░░░   4 / 10  (40%)                │
│  ⚠️ Behind pace — schedule peer sessions!                       │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  RECENT HOURS LOG                                                │
│                                                                  │
│  Jan 8, 2026  │ Case Supervision │ 1.5 hrs │ ✓ Approved        │
│  Jan 6, 2026  │ Client Session   │ 1.0 hrs │ ✓ Logged          │
│  Jan 5, 2026  │ Group Call       │ 1.5 hrs │ ✓ Attended        │
│  Jan 3, 2026  │ Case Supervision │ 2.0 hrs │ ✓ Approved        │
│  Jan 2, 2026  │ Client Session   │ 1.0 hrs │ ✓ Logged          │
│                                                                  │
│                              [VIEW FULL LOG] [EXPORT PDF]        │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ⚡ LOG NEW HOURS                                               │
│                                                                  │
│  [+ CLIENT SESSION] [+ PEER CONSULTATION] [+ OTHER]             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Mentor Management

### Mentor Roles & Compensation

| Role | Responsibility | Compensation Model |
|------|----------------|-------------------|
| **Staff Mentor** | Full-time, multiple practitioners | Salary |
| **Contract Mentor** | Part-time, specialty-specific | Per-hour ($75-150) |
| **MC-™ Graduate Mentor** | Supervise CP™ in their specialty | Per case ($25-50) |
| **Guest Expert** | Special sessions | Per session ($200-500) |

### Mentor Assignment Rules

```
┌─────────────────────────────────────────────────────────────────┐
│                    MENTOR ASSIGNMENT LOGIC                       │
│                                                                  │
│  When practitioner enrolls in CP™ or BC-™:                      │
│                                                                  │
│  1. Match by SPECIALTY                                          │
│     └─ FM practitioner → FM-certified mentor                    │
│     └─ WH practitioner → WH-certified mentor                    │
│                                                                  │
│  2. Check CAPACITY                                              │
│     └─ Staff mentor: max 25 practitioners                       │
│     └─ Contract mentor: max 15 practitioners                    │
│     └─ MC-™ mentor: max 10 practitioners                        │
│                                                                  │
│  3. Consider TIER                                               │
│     └─ CP™ → Can be supervised by BC-™+ mentors                │
│     └─ BC-™ → Must be supervised by MC-™ or Staff              │
│                                                                  │
│  4. Allow PREFERENCE (if available)                             │
│     └─ Practitioner can request specific mentor                 │
│     └─ Subject to capacity and specialty match                  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Mentor Quality Metrics

| Metric | Target | Description |
|--------|--------|-------------|
| Response Time | < 48 hours | Time to review submitted case |
| Review Quality | 4.5+ / 5 | Practitioner ratings of feedback |
| Completion Rate | 85%+ | Practitioners completing certification |
| Session Attendance | 95%+ | Showing up for scheduled sessions |

### Mentor Dashboard (Admin View)

```
┌─────────────────────────────────────────────────────────────────┐
│                    MENTOR MANAGEMENT                             │
│                                                                  │
│  Active Mentors: 12  |  Practitioners Supervised: 156           │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Dr. Sarah Martinez          STAFF MENTOR                   │ │
│  │ Specialty: Functional Medicine                             │ │
│  │ Practitioners: 18/25  |  Cases/Week: 12  |  Rating: 4.8   │ │
│  │ Avg Response: 18 hours  |  Status: Active                  │ │
│  │                              [VIEW] [ADJUST CAPACITY]      │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Amanda Brooks, MC-FMP™       MC-™ MENTOR                   │ │
│  │ Specialty: Functional Medicine                             │ │
│  │ Practitioners: 8/10  |  Cases/Week: 6  |  Rating: 4.6     │ │
│  │ Avg Response: 36 hours  |  Status: Active                  │ │
│  │                              [VIEW] [ADJUST CAPACITY]      │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Dr. Lisa Chen               CONTRACT MENTOR                 │ │
│  │ Specialty: Women's Health                                  │ │
│  │ Practitioners: 12/15  |  Cases/Week: 8  |  Rating: 4.9    │ │
│  │ Avg Response: 24 hours  |  Status: Active                  │ │
│  │                              [VIEW] [ADJUST CAPACITY]      │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  [+ ADD MENTOR]  [VIEW UNASSIGNED PRACTITIONERS]                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Client Referral Network

### For BC-™ Members Only

```
┌─────────────────────────────────────────────────────────────────┐
│                    CLIENT REFERRAL NETWORK                       │
│                    (BC-™ Members Only)                           │
│                                                                  │
│  Your Referral Status: ACTIVE                                   │
│  Specialty: Functional Medicine                                  │
│  Location: San Diego, CA                                         │
│  Accepts: In-person + Virtual                                    │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  📊 YOUR REFERRAL STATS                                         │
│                                                                  │
│  This Month:                                                     │
│  • Leads Received: 5                                             │
│  • Leads Claimed: 4                                              │
│  • Converted to Clients: 2                                       │
│  • Conversion Rate: 50%                                          │
│                                                                  │
│  All Time:                                                       │
│  • Total Leads: 42                                               │
│  • Clients Gained: 18                                            │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  🆕 AVAILABLE LEADS (3 new)                                     │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Lead #4892                              Posted: 2 hours ago │ │
│  │ Location: La Jolla, CA (8 miles)                           │ │
│  │ Concern: Chronic fatigue, gut issues                       │ │
│  │ Preference: In-person preferred                            │ │
│  │ Budget: $200-400/session                                   │ │
│  │                                                             │ │
│  │                    [CLAIM LEAD — $35]  [PASS]              │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Lead #4891                              Posted: 5 hours ago │ │
│  │ Location: Virtual (anywhere)                               │ │
│  │ Concern: Hormonal imbalance, perimenopause                 │ │
│  │ Preference: Virtual only                                   │ │
│  │ Budget: $150-300/session                                   │ │
│  │                                                             │ │
│  │                    [CLAIM LEAD — $35]  [PASS]              │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  ⚙️ REFERRAL SETTINGS                                          │
│                                                                  │
│  Receiving leads: [ON]                                           │
│  Max leads/month: [10 ▼]                                        │
│  Specialties: ☑ Gut Health  ☑ Fatigue  ☐ Autoimmune            │
│  Client type: ☑ In-person  ☑ Virtual                           │
│                                                                  │
│                              [UPDATE SETTINGS]                   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Referral Pricing Options

| Model | Price | Description |
|-------|-------|-------------|
| **Pay-per-lead** | $25-50/lead | One-time fee per claimed lead |
| **Monthly Subscription** | $197/month | Unlimited leads, priority access |
| **Success Fee** | 10% | % of first client payment |

---

## Database Schema

### Core Models

```prisma
// ============================================
// PRACTITIONER & CLIENT MANAGEMENT
// ============================================

model PractitionerProfile {
  id                String   @id @default(cuid())
  userId            String   @unique
  user              User     @relation(fields: [userId], references: [id])

  // Certification status
  currentTier       CertificationTier  // CP, BC, MC
  specialty         String             // FM, WH, NC, etc.
  certificationDate DateTime?

  // Supervision
  supervisorId      String?
  supervisor        Mentor?  @relation("SupervisorAssignment", fields: [supervisorId], references: [id])

  // Practice info
  practiceLocation  String?
  acceptsVirtual    Boolean  @default(true)
  acceptsInPerson   Boolean  @default(false)

  // Referral settings (BC-™ only)
  acceptsReferrals  Boolean  @default(false)
  maxReferralsMonth Int      @default(10)
  referralSpecialties String[]

  // Relations
  clients           PractitionerClient[]
  caseSubmissions   CaseSubmission[]
  hoursLog          HoursLogEntry[]
  referrals         ClientReferral[]

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

model PractitionerClient {
  id                String   @id @default(cuid())
  practitionerId    String
  practitioner      PractitionerProfile @relation(fields: [practitionerId], references: [id])

  // Client info (pseudonymized)
  pseudonym         String              // "Maria G."
  ageRange          String?             // "40-50"
  gender            String?
  chiefConcerns     String
  specialty         String

  // Status
  status            ClientStatus        // ACTIVE, INACTIVE, ARCHIVED
  startDate         DateTime
  lastSessionDate   DateTime?
  sessionCount      Int      @default(0)

  // Private notes (not shared with supervisor)
  privateNotes      String?

  // Relations
  caseSubmissions   CaseSubmission[]

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum ClientStatus {
  ACTIVE
  INACTIVE
  ARCHIVED
}

// ============================================
// CASE SUBMISSION & REVIEW
// ============================================

model CaseSubmission {
  id                String   @id @default(cuid())

  // Relationships
  practitionerId    String
  practitioner      PractitionerProfile @relation(fields: [practitionerId], references: [id])
  clientId          String
  client            PractitionerClient @relation(fields: [clientId], references: [id])
  reviewerId        String?
  reviewer          Mentor?  @relation(fields: [reviewerId], references: [id])

  // Session details
  sessionDate       DateTime
  sessionType       SessionType         // INITIAL_INTAKE, FOLLOW_UP, PROTOCOL_REVIEW, PROGRESS_CHECK
  durationMinutes   Int

  // Clinical content
  chiefConcerns     String              // Session focus
  relevantHistory   String              // Updates since last session
  assessment        String              // Practitioner's clinical reasoning
  recommendations   String              // Proposed protocol/plan
  questionsForSupervisor String?        // Questions for mentor

  // Attachments
  attachments       CaseAttachment[]

  // Hours
  hoursRequested    Decimal
  hoursApproved     Decimal?
  hourType          HourType?

  // Review
  status            CaseStatus          // PENDING, IN_REVIEW, REVIEWED, REVISION_REQUESTED

  // Mentor feedback
  ratingClinicalReasoning  Int?         // 1-5
  ratingAssessment         Int?         // 1-5
  ratingProtocolDesign     Int?         // 1-5
  ratingDocumentation      Int?         // 1-5
  ratingCommunication      Int?         // 1-5
  overallRating            Decimal?     // Calculated average

  detailedFeedback  String?
  actionItems       String[]            // Array of action items

  submittedAt       DateTime @default(now())
  reviewedAt        DateTime?

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum SessionType {
  INITIAL_INTAKE
  FOLLOW_UP
  PROTOCOL_REVIEW
  PROGRESS_CHECK
}

enum CaseStatus {
  DRAFT
  PENDING
  IN_REVIEW
  REVIEWED
  REVISION_REQUESTED
}

enum HourType {
  CLIENT_SESSION
  CASE_SUPERVISION
  GROUP_SUPERVISION
  PEER_CONSULTATION
  OTHER
}

model CaseAttachment {
  id              String   @id @default(cuid())
  caseSubmissionId String
  caseSubmission  CaseSubmission @relation(fields: [caseSubmissionId], references: [id])

  fileName        String
  fileType        String
  fileUrl         String
  fileSize        Int

  createdAt       DateTime @default(now())
}

// ============================================
// SUPERVISION HOURS
// ============================================

model HoursLogEntry {
  id                String   @id @default(cuid())
  practitionerId    String
  practitioner      PractitionerProfile @relation(fields: [practitionerId], references: [id])

  // Hour details
  date              DateTime
  hourType          HourType
  hours             Decimal
  description       String

  // Verification
  status            HoursStatus         // LOGGED, PENDING_APPROVAL, APPROVED, REJECTED
  approvedById      String?
  approvedBy        Mentor?  @relation("HoursApproval", fields: [approvedById], references: [id])
  approvedAt        DateTime?

  // Link to case if applicable
  caseSubmissionId  String?

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum HoursStatus {
  LOGGED
  PENDING_APPROVAL
  APPROVED
  REJECTED
}

// ============================================
// MENTORS
// ============================================

model Mentor {
  id                String   @id @default(cuid())
  userId            String   @unique
  user              User     @relation(fields: [userId], references: [id])

  // Mentor info
  role              MentorRole          // STAFF, CONTRACT, MC_GRADUATE, GUEST
  specialties       String[]            // ["FM", "WH"]
  bio               String?

  // Capacity
  maxPractitioners  Int      @default(20)
  isAcceptingNew    Boolean  @default(true)

  // Compensation (for contract/MC mentors)
  hourlyRate        Decimal?
  perCaseRate       Decimal?

  // Metrics
  avgResponseHours  Decimal?
  avgRating         Decimal?
  totalCasesReviewed Int     @default(0)

  // Status
  status            MentorStatus        // ACTIVE, INACTIVE, ON_LEAVE

  // Relations
  practitioners     PractitionerProfile[] @relation("SupervisorAssignment")
  caseReviews       CaseSubmission[]
  hoursApprovals    HoursLogEntry[] @relation("HoursApproval")
  sessions          SupervisionSession[]

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum MentorRole {
  STAFF
  CONTRACT
  MC_GRADUATE
  GUEST
}

enum MentorStatus {
  ACTIVE
  INACTIVE
  ON_LEAVE
}

// ============================================
// SUPERVISION SESSIONS
// ============================================

model SupervisionSession {
  id                String   @id @default(cuid())

  // Participants
  mentorId          String
  mentor            Mentor   @relation(fields: [mentorId], references: [id])

  // Session type
  type              SupervisionSessionType // ONE_ON_ONE, GROUP, PEER
  title             String

  // Scheduling
  scheduledAt       DateTime
  durationMinutes   Int

  // Meeting details
  meetingUrl        String?
  recordingUrl      String?

  // Notes
  notes             String?

  // Status
  status            SessionStatus       // SCHEDULED, COMPLETED, CANCELLED, NO_SHOW

  // Attendees (for group sessions)
  attendees         SessionAttendee[]

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum SupervisionSessionType {
  ONE_ON_ONE
  GROUP
  PEER
  MASTERMIND
}

enum SessionStatus {
  SCHEDULED
  COMPLETED
  CANCELLED
  NO_SHOW
}

model SessionAttendee {
  id                String   @id @default(cuid())
  sessionId         String
  session           SupervisionSession @relation(fields: [sessionId], references: [id])
  practitionerId    String

  attended          Boolean  @default(false)
  hoursAwarded      Decimal?

  createdAt         DateTime @default(now())
}

// ============================================
// CLIENT REFERRALS
// ============================================

model ClientReferral {
  id                String   @id @default(cuid())

  // Lead info
  leadSource        String              // "website", "ad", "partner"
  location          String
  isVirtual         Boolean
  concernSummary    String
  budgetRange       String?
  preferenceNotes   String?

  // Status
  status            ReferralStatus      // AVAILABLE, CLAIMED, CONVERTED, EXPIRED

  // Assignment
  claimedById       String?
  claimedBy         PractitionerProfile? @relation(fields: [claimedById], references: [id])
  claimedAt         DateTime?

  // Pricing
  referralFee       Decimal?            // Fee charged to practitioner
  feePaid           Boolean  @default(false)

  // Outcome
  converted         Boolean  @default(false)
  convertedAt       DateTime?

  // Expiration
  expiresAt         DateTime

  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

enum ReferralStatus {
  AVAILABLE
  CLAIMED
  CONVERTED
  EXPIRED
  RETURNED
}

enum CertificationTier {
  FC    // Foundation Certified
  CP    // Certified Professional
  BC    // Board Certified
  MC    // Master Certified
}
```

---

## UI Specifications

### Navigation Updates

Add to `dashboard-nav.tsx` for CP™+ certified users:

```typescript
// Show "My Practice" section for certified practitioners (CP™+)
const hasPractitionerAccess = user?.certifications?.some(c =>
  ['CP', 'BC', 'MC'].includes(c.tier)
);

const practitionerNavItems: NavItem[] = [
  { href: "/practice/dashboard", label: "Practice Dashboard", icon: LayoutDashboard },
  { href: "/practice/clients", label: "My Clients", icon: Users },
  { href: "/practice/cases", label: "Case Submissions", icon: FileText },
  { href: "/practice/supervision", label: "Supervision", icon: GraduationCap },
  { href: "/practice/tools", label: "Practice Tools", icon: Wrench },
  { href: "/practice/referrals", label: "Client Referrals", icon: UserPlus, locked: tier !== 'BC' && tier !== 'MC' },
];

// In render:
{hasPractitionerAccess && (
  <>
    <div className="pt-3 mt-3 border-t border-burgundy-600/30">
      <p className="px-3 py-1 text-xs font-semibold text-blue-400 uppercase tracking-wider">
        📋 My Practice
      </p>
    </div>
    {practitionerNavItems.map((item) => (
      // ... render nav items
    ))}
  </>
)}
```

### Routes to Create

```
/practice
├── /dashboard          — Practice overview
├── /clients            — Client list
│   ├── /new           — Add new client
│   └── /[id]          — Client detail
├── /cases              — Case submissions
│   ├── /new           — Submit new case
│   ├── /[id]          — View case & feedback
│   └── /[id]/edit     — Edit draft case
├── /supervision        — Supervision management
│   ├── /sessions      — Session calendar
│   └── /hours         — Hours log
├── /tools              — Practice tools library
└── /referrals          — Client referral network (BC-™+)

/coach (Coach Workspace)
├── /dashboard          — Coach overview
├── /practitioners      — My practitioners
│   └── /[id]          — Practitioner detail
├── /cases              — Case reviews
│   └── /[id]          — Review case
├── /sessions           — Supervision sessions
├── /hours              — Hours certification
└── /resources          — Mentor resources
```

---

## Implementation Phases

### Phase 1: Foundation (Weeks 1-4)

- [ ] Database schema migration
- [ ] Create PractitionerProfile model
- [ ] Create basic My Clients CRUD
- [ ] Create Mentor model and assignment logic
- [ ] Update navigation for practitioner access

### Phase 2: Case System (Weeks 5-8)

- [ ] Case submission form
- [ ] Case review interface (mentor side)
- [ ] Case status workflow
- [ ] Email notifications for submissions/reviews
- [ ] Attachment handling

### Phase 3: Hours Tracking (Weeks 9-12)

- [ ] Hours logging interface
- [ ] Hours approval workflow
- [ ] Progress tracking dashboard
- [ ] Hours requirements by tier
- [ ] Certificate eligibility checks

### Phase 4: Supervision Sessions (Weeks 13-16)

- [ ] Session scheduling system
- [ ] Calendar integration
- [ ] Video meeting links (Zoom/Meet)
- [ ] Session notes
- [ ] Attendance tracking

### Phase 5: Referral Network (Weeks 17-20)

- [ ] Lead intake system
- [ ] Lead distribution algorithm
- [ ] Claim/payment flow
- [ ] Referral settings
- [ ] Analytics dashboard

### Phase 6: Polish & Scale (Weeks 21-24)

- [ ] Mentor matching optimization
- [ ] Quality metrics dashboard
- [ ] Automated reminders
- [ ] Mobile optimization
- [ ] Performance optimization

---

## Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Jan 2026 | Strategy Team | Initial document |

---

*This document is proprietary to AccrediPro Standards Institute International FZE and AccrediPro Standards Institute LLC. All rights reserved.*
